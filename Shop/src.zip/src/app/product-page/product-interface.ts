export interface IProduct {
    title:string,
    material:string,
    id:number,
    img:string,
    price:number,
} 