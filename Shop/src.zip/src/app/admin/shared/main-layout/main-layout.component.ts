import { Component, ViewChild } from '@angular/core';



// const btnRings = document.getElementById('rings')

// btnRings.addEventListener('click', function(){
//   console.log('hey ring')
// })



@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.scss']
})
export class MainLayoutComponent {
  // @ViewChild('rings')
 }

